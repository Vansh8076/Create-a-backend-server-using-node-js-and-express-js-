const express = require("express");
const { body, validationResult } = require("express-validator");
const Blog = require("../models/Blog");
const authenticate = require("../middleware/auth");

const router = express.Router();

function checkValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
}

// GET /api/blogs - public list of blogs
router.get("/", async (req, res, next) => {
  try {
    const blogs = await Blog.find()
      .populate("author", "name")
      .sort({ createdAt: -1 });
    res.json({ success: true, count: blogs.length, blogs });
  } catch (error) {
    next(error);
  }
});

// GET /api/blogs/:id - public single blog
router.get("/:id", async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id).populate("author", "name");
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found." });
    res.json({ success: true, blog });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({ success: false, message: "Invalid blog ID." });
    }
    next(error);
  }
});

// POST /api/blogs - create a blog (login required)
router.post(
  "/",
  authenticate,
  [
    body("title").trim().notEmpty().withMessage("Title is required.").isLength({ max: 120 }),
    body("content").trim().notEmpty().withMessage("Content is required.").isLength({ max: 10000 })
  ],
  checkValidation,
  async (req, res, next) => {
    try {
      const blog = await Blog.create({
        title: req.body.title,
        content: req.body.content,
        author: req.user.id
      });
      const populatedBlog = await blog.populate("author", "name");
      res.status(201).json({ success: true, message: "Blog created.", blog: populatedBlog });
    } catch (error) {
      next(error);
    }
  }
);

// PUT /api/blogs/:id - update only your own blog
router.put(
  "/:id",
  authenticate,
  [
    body("title").optional().trim().notEmpty().isLength({ max: 120 }),
    body("content").optional().trim().notEmpty().isLength({ max: 10000 })
  ],
  checkValidation,
  async (req, res, next) => {
    try {
      if (!req.body.title && !req.body.content) {
        return res.status(400).json({ success: false, message: "Provide a title or content to update." });
      }
      const blog = await Blog.findById(req.params.id);
      if (!blog) return res.status(404).json({ success: false, message: "Blog not found." });
      if (blog.author.toString() !== req.user.id) {
        return res.status(403).json({ success: false, message: "You can update only your own blogs." });
      }

      if (req.body.title !== undefined) blog.title = req.body.title;
      if (req.body.content !== undefined) blog.content = req.body.content;
      await blog.save();
      await blog.populate("author", "name");
      res.json({ success: true, message: "Blog updated.", blog });
    } catch (error) {
      if (error.name === "CastError") {
        return res.status(400).json({ success: false, message: "Invalid blog ID." });
      }
      next(error);
    }
  }
);

// DELETE /api/blogs/:id - delete only your own blog
router.delete("/:id", authenticate, async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ success: false, message: "Blog not found." });
    if (blog.author.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: "You can delete only your own blogs." });
    }
    await blog.deleteOne();
    res.json({ success: true, message: "Blog deleted." });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({ success: false, message: "Invalid blog ID." });
    }
    next(error);
  }
});

module.exports = router;
