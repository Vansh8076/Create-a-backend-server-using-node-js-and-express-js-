const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const User = require("../models/User");

const router = express.Router();

function checkValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
}

function createToken(userId) {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "1d"
  });
}

// POST /api/auth/register
router.post(
  "/register",
  [
    body("name").trim().notEmpty().withMessage("Name is required."),
    body("email").isEmail().withMessage("Enter a valid email address."),
    body("password").isLength({ min: 8 }).withMessage("Password must be at least 8 characters.")
  ],
  checkValidation,
  async (req, res, next) => {
    try {
      const { name, email, password } = req.body;
      const normalizedEmail = email.toLowerCase();
      const existingUser = await User.findOne({ email: normalizedEmail });
      if (existingUser) {
        return res.status(409).json({ success: false, message: "An account with this email already exists." });
      }

      const hashedPassword = await bcrypt.hash(password, 12);
      const user = await User.create({ name, email: normalizedEmail, password: hashedPassword });
      const token = createToken(user._id);

      res.status(201).json({
        success: true,
        message: "Registration successful.",
        token,
        user: { id: user._id, name: user.name, email: user.email }
      });
    } catch (error) {
      next(error);
    }
  }
);

// POST /api/auth/login
router.post(
  "/login",
  [
    body("email").isEmail().withMessage("Enter a valid email address."),
    body("password").notEmpty().withMessage("Password is required.")
  ],
  checkValidation,
  async (req, res, next) => {
    try {
      const { email, password } = req.body;
      const user = await User.findOne({ email: email.toLowerCase() }).select("+password");
      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ success: false, message: "Incorrect email or password." });
      }

      const token = createToken(user._id);
      res.json({
        success: true,
        message: "Login successful.",
        token,
        user: { id: user._id, name: user.name, email: user.email }
      });
    } catch (error) {
      next(error);
    }
  }
);

module.exports = router;
