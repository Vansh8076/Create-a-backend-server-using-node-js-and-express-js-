const API = "/api";
const $ = (id) => document.getElementById(id);

let token = localStorage.getItem("blogToken");
let currentUser = JSON.parse(localStorage.getItem("blogUser") || "null");
let authMode = "login";
let editingBlogId = null;

function showNotice(message, isError = false) {
  $("notice").textContent = message;
  $("notice").classList.toggle("error", isError);
}

async function apiRequest(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API}${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || data.errors?.[0]?.msg || "Request failed.");
  return data;
}

function setAuthMode(mode) {
  authMode = mode;
  const registering = mode === "register";
  $("nameLabel").classList.toggle("hidden", !registering);
  $("nameInput").required = registering;
  $("passwordInput").autocomplete = registering ? "new-password" : "current-password";
  $("authSubmit").textContent = registering ? "Create account" : "Login";
  $("loginTab").classList.toggle("active", !registering);
  $("registerTab").classList.toggle("active", registering);
}

function updateUI() {
  const loggedIn = Boolean(token && currentUser);
  $("authSection").classList.toggle("hidden", loggedIn);
  $("composer").classList.toggle("hidden", !loggedIn);
  $("logoutButton").classList.toggle("hidden", !loggedIn);
  $("showLogin").classList.toggle("hidden", loggedIn);
  $("showRegister").classList.toggle("hidden", loggedIn);
}

function logout() {
  token = null;
  currentUser = null;
  localStorage.removeItem("blogToken");
  localStorage.removeItem("blogUser");
  resetEditor();
  updateUI();
  loadBlogs();
  showNotice("You have logged out.");
}

$("loginTab").addEventListener("click", () => setAuthMode("login"));
$("registerTab").addEventListener("click", () => setAuthMode("register"));
$("showLogin").addEventListener("click", () => { setAuthMode("login"); $("authSection").scrollIntoView(); });
$("showRegister").addEventListener("click", () => { setAuthMode("register"); $("authSection").scrollIntoView(); });
$("logoutButton").addEventListener("click", logout);
$("refreshButton").addEventListener("click", loadBlogs);

$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const payload = {
      email: $("emailInput").value.trim(),
      password: $("passwordInput").value
    };
    if (authMode === "register") payload.name = $("nameInput").value.trim();
    const result = await apiRequest(`/auth/${authMode === "register" ? "register" : "login"}`, {
      method: "POST", body: JSON.stringify(payload)
    });
    token = result.token;
    currentUser = result.user;
    localStorage.setItem("blogToken", token);
    localStorage.setItem("blogUser", JSON.stringify(currentUser));
    $("authForm").reset();
    updateUI();
    showNotice(`Welcome, ${currentUser.name}!`);
    await loadBlogs();
  } catch (error) {
    showNotice(error.message, true);
  }
});

function resetEditor() {
  editingBlogId = null;
  $("blogForm").reset();
  $("composerTitle").textContent = "Create a blog";
  $("saveBlog").textContent = "Publish blog";
  $("cancelEdit").classList.add("hidden");
}

$("cancelEdit").addEventListener("click", resetEditor);

$("blogForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = {
    title: $("blogTitle").value.trim(),
    content: $("blogContent").value.trim()
  };
  try {
    const editing = Boolean(editingBlogId);
    await apiRequest(editing ? `/blogs/${editingBlogId}` : "/blogs", {
      method: editing ? "PUT" : "POST",
      body: JSON.stringify(payload)
    });
    resetEditor();
    showNotice(editing ? "Blog updated successfully." : "Blog published successfully.");
    await loadBlogs();
  } catch (error) {
    showNotice(error.message, true);
  }
});

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[char]));
}

function formatDate(value) {
  return new Date(value).toLocaleDateString(undefined, { year:"numeric", month:"short", day:"numeric" });
}

async function loadBlogs() {
  try {
    const result = await apiRequest("/blogs");
    const list = $("blogList");
    if (!result.blogs.length) {
      list.innerHTML = "<p>No blogs yet. Log in and publish the first one!</p>";
      return;
    }

    list.innerHTML = result.blogs.map((blog) => {
      const isOwner = currentUser && blog.author && blog.author._id === currentUser.id;
      const actions = isOwner ? `
        <div class="card-actions">
          <button data-edit="${blog._id}">Edit</button>
          <button data-delete="${blog._id}">Delete</button>
        </div>` : "";
      return `
        <article class="blog-card">
          <h3>${escapeHTML(blog.title)}</h3>
          <div class="blog-meta">By ${escapeHTML(blog.author?.name || "Unknown")} · ${formatDate(blog.createdAt)}</div>
          <p>${escapeHTML(blog.content)}</p>
          ${actions}
        </article>`;
    }).join("");

    list.querySelectorAll("[data-edit]").forEach((button) => {
      button.addEventListener("click", () => {
        const blog = result.blogs.find((item) => item._id === button.dataset.edit);
        if (!blog) return;
        editingBlogId = blog._id;
        $("blogTitle").value = blog.title;
        $("blogContent").value = blog.content;
        $("composerTitle").textContent = "Edit your blog";
        $("saveBlog").textContent = "Save changes";
        $("cancelEdit").classList.remove("hidden");
        $("composer").scrollIntoView({ behavior:"smooth" });
      });
    });

    list.querySelectorAll("[data-delete]").forEach((button) => {
      button.addEventListener("click", async () => {
        if (!confirm("Delete this blog? This cannot be undone.")) return;
        try {
          await apiRequest(`/blogs/${button.dataset.delete}`, { method:"DELETE" });
          showNotice("Blog deleted.");
          await loadBlogs();
        } catch (error) {
          showNotice(error.message, true);
        }
      });
    });
  } catch (error) {
    $("blogList").innerHTML = `<p>${escapeHTML(error.message)}</p>`;
  }
}

updateUI();
loadBlogs();
