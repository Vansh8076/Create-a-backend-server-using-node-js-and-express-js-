# Blog Management System

A beginner-friendly full-stack blog application built with **Node.js, Express.js, MongoDB, JWT and vanilla JavaScript**.

## Features

- User registration and login
- Password hashing with bcrypt
- JWT-based authentication
- Create, read, update and delete (CRUD) blog posts
- Users can edit or delete only their own posts
- Responsive frontend served by Express
- Input validation and clear API error responses

## Project structure

```text
blog-management-system/
├── middleware/
│   └── auth.js
├── models/
│   ├── Blog.js
│   └── User.js
├── public/
│   ├── app.js
│   ├── index.html
│   └── style.css
├── routes/
│   ├── authRoutes.js
│   └── blogRoutes.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Requirements

- Node.js 18 or newer
- npm
- MongoDB running locally, or a MongoDB Atlas database

## Run the project

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Create your environment file by copying `.env.example` to `.env`.

   On Windows PowerShell:

   ```powershell
   Copy-Item .env.example .env
   ```

   On macOS/Linux:

   ```bash
   cp .env.example .env
   ```

5. Edit `.env`. Set `MONGODB_URI` to your local MongoDB connection string or MongoDB Atlas connection string. Replace `JWT_SECRET` with a long random secret (at least 20 characters). **Never upload `.env` to GitHub.**

6. Start the server:

   ```bash
   npm run dev
   ```

   Or use `npm start` for normal mode.

7. Open **http://localhost:5000** in your browser.

## API endpoints

Base URL: `http://localhost:5000/api`

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/health` | Public | Check server status |
| POST | `/auth/register` | Public | Register a user |
| POST | `/auth/login` | Public | Log in |
| GET | `/blogs` | Public | Get all blogs |
| GET | `/blogs/:id` | Public | Get one blog |
| POST | `/blogs` | Login required | Create a blog |
| PUT | `/blogs/:id` | Owner only | Update a blog |
| DELETE | `/blogs/:id` | Owner only | Delete a blog |

### Example registration request

`POST /api/auth/register`

```json
{
  "name": "Aarav",
  "email": "aarav@example.com",
  "password": "example123"
}
```

### Example login request

`POST /api/auth/login`

```json
{
  "email": "aarav@example.com",
  "password": "example123"
}
```

The authentication response contains a JWT token. For protected requests, send this header:

```text
Authorization: Bearer YOUR_TOKEN_HERE
```

### Example create-blog request

`POST /api/blogs`

```json
{
  "title": "My First Blog",
  "content": "This is the content of my first blog post."
}
```

## Upload to GitHub

1. Create a new empty repository on GitHub, for example `blog-management-system`.
2. Extract this ZIP file.
3. Open a terminal inside the extracted project folder.
4. Run:

   ```bash
   git init
   git add .
   git commit -m "Add blog management system"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/blog-management-system.git
   git push -u origin main
   ```

5. Replace `YOUR-USERNAME` with your GitHub username.

You can also upload the extracted files using GitHub's web interface. Do not upload `node_modules/` or `.env`.

## Testing checklist

- [ ] Register a new account
- [ ] Log in
- [ ] Create a blog
- [ ] Refresh and confirm the blog remains visible
- [ ] Edit your own blog
- [ ] Delete your own blog
- [ ] Log out and confirm protected actions require login

## Notes

- MongoDB must be available before the server starts.
- This is an educational starter project. Before public production deployment, add rate limiting, stronger security headers, secure cookie-based token storage, logging, automated tests and deployment configuration.
